from .lenet import LeNet
from .minivggnet import MiniVGGNet
from .shallownet import ShallowNet
